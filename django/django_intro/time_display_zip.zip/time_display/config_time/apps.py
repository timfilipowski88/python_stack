from django.apps import AppConfig


class ConfigTimeConfig(AppConfig):
    name = 'config_time'
