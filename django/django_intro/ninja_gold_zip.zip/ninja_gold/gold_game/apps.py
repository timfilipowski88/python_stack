from django.apps import AppConfig


class GoldGameConfig(AppConfig):
    name = 'gold_game'
